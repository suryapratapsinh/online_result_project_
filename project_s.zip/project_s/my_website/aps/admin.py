from django.contrib import admin
from aps.models import modelclass

class homeResult(admin.ModelAdmin):
    list_display=('Enrollment','Seatno')
# Register your models here.

admin.site.register(modelclass,homeResult)