from django.db import models

# Create your models here.


class modelclass(models.Model):

    Enrollment = models.CharField(max_length=50)
    Seatno     = models.CharField(max_length=50)