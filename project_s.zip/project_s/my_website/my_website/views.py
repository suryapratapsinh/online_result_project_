from django.shortcuts import render,HttpResponse
from aps.models import modelclass
from django.contrib import messages



# Create your views here.
def site(request):
    return render(request, "C:/Users/suryapratapsinh/Desktop/project_s/my_website/templates/site.html")

def studentlogin(request):
    
    if request.method == "POST":
        if request.POST.get('Enrollment') and request.POST.get('Seatno'):

            saverecord = modelclass()
            saverecord.Enrollment=request.POST.get('Enrollment')
            saverecord.Seatno=request.POST.get('seatno')
            saverecord.save()
            #result.save()
            messages.success(request, "msg sented")
            return render(request, "C:/Users/suryapratapsinh/Desktop/project_s/my_website/templates/studentlogin.html")

       

    #return HttpResponse("this is my about page")
    return render(request, "C:/Users/suryapratapsinh/Desktop/project_s/my_website/templates/studentlogin.html")

def studentresult(request):
    #return HttpResponse("this is my service page")
    return render(request, "C:/Users/suryapratapsinh/Desktop/project_s/my_website/templates/studentresult.html")
